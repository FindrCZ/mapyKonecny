<style>
    .form-inline{
        justify-content: center;
        
    }
    .vyhledat{
        justify-content: center;
    }
</style>
<div class="container">
   <br> 
    <center><h1>Města s počty přijatými žáky</h1></center>
    <br>
<form class="form-inline" action="" method="post">
    <input type="text"  list="pocet" name="pocet" class="form-control">  
	<datalist id="pocet">                    
             <option value="Počtu přijatých žáků">Počtu přijatých žáků</option>      
	</datalist>
    <input class="btn btn-default" type="submit" name="filtr" value="Filtrovat"> 
   
        <input class="form-control" type="text" name="title" value="" placeholder="Vyhledat..">
        <input class="btn btn-default" type="submit" name="submit" value="Vyhledat"> 
    </form>
     </form>
    <div class="column">
            <div style="margin-top: 50px; background-color: white">
                <table class="table table-lumen" style="" >
                    <thead>
                        <tr>
                            <th>Škola</th>
                            <th>Počet přijatých</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($skoly as $skola){
                            echo    "<tr>";
                            echo        "<td>", $skola->nazev, "</td>";
                             echo        "<td>", $skola->pocet, "</td>";
                            /* echo        "<td>", $mesta->pocet_prijatych, "</td>";
                            echo        "<td>", $mesta->obor, "</td>";
                            echo        "<td><a href='"."'>Editace</a></td>";
                           */
                            echo    "</tr>";
                        }
                        ?>
       
                    </tbody>
                </table>                 
        
            </div>

    </div>
</div>
<footer class="page-footer font-small blue">
  <div class="footer-copyright text-center py-3">© 2020 Copyright:
    <a href=""> Ondřej Konečný</a>
  </div>
</footer>