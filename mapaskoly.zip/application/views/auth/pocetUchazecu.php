<div class="container mt-4">
    <h1 class="display-4 text-center">Počet <span>přijatých</span></h1>
   
      <form id="book-form" method="post"> 
        <div class="form-group">     
            <label for="skola">Název školy</label>
            
            <input type="number" list="skola" name="skola" class="form-control" required>  
	<datalist id="skola">        
            <?php foreach ($skoly as $skola){  ?>
            <option value="<?php echo $skola->id; ?>"> <?php echo $skola->nazev; ?> </option>         
             <?php } ?>
	</datalist>  
        </div>
        <div class="form-group">
          <label for="pocet">Počet přijatých</label>
          <input type="number" id="pocet" class="form-control" name="pocet" min="0" required>        
        </div>
        <div class="form-group">
          <label for="rok">Rok</label>
    <input type="number" id="rok" class="form-control" name="rok" min="2000"  required>        
        </div>
        <div class="form-group">
          <label for="obor">Obor</label>
          <input type="number" id="obor" max="2" min="1" placeholder="1 = Obchodní akademie, 2 = Informační technologie" class="form-control" name="obor" required>
        </div>
        
          <input type="submit" value="Přidat přijaté" class="btn btn-primary btn-block" name="ulozit">
      </form>
      
  </div>