<?php

class model extends CI_Model {


    public function __construct() {
        parent::__construct();
    }
    public function get_skoly(){   
           $query = $this->db->query("select pocet_prijatych.pocet, pocet_prijatych.skola, skola.nazev, skola.id from skola, pocet_prijatych where pocet_prijatych.skola = skola.id");
           return $query->result(); 
    }
    public function skolyPodlePrijatych(){
           $query = $this->db->query("select pocet_prijatych.pocet, pocet_prijatych.skola, skola.nazev, skola.id from skola, pocet_prijatych where pocet_prijatych.skola = skola.id order by pocet_prijatych.pocet DESC");
           return $query->result(); 
    }
    public function search($key){
        $query = $this->db->query("select pocet_prijatych.pocet, pocet_prijatych.skola, skola.nazev, skola.id from skola, pocet_prijatych where pocet_prijatych.skola = skola.id AND skola.nazev like '%$key%'");
        return $query->result(); 
    }
    public function get_mapa(){
          $query = $this->db->query("select pocet_prijatych.pocet, pocet_prijatych.skola, skola.nazev, skola.id, skola.geo_lat, skola.geo_long from skola, pocet_prijatych where pocet_prijatych.skola = skola.id");
           return $query->result();
    }
    public function mapaSearch($key){
          $query = $this->db->query("select pocet_prijatych.pocet, pocet_prijatych.skola, skola.nazev, skola.id, skola.geo_lat, skola.geo_long from skola, pocet_prijatych where pocet_prijatych.skola = skola.id AND skola.nazev like '%$key%'");
           return $query->result();
    }
    public function get_mesta(){
        $this->db->order_by("id");
        $query = $this->db->get("mesto");   
        return $query->result();
    }
    public function skolyData(){
        $this->db->order_by("id");
        $query = $this->db->get("skola");   
        return $query->result();
    }
    public function pridatPrijate($obor,$skola,$pocet,$rok)
	{
	$query="INSERT INTO pocet_prijatych (obor, skola, pocet, rok) VALUES ('$obor','$skola','$pocet','$rok');";
	$this->db->query($query);
	}
         public function pridatSkolu($nazev,$mesto,$geo_lat,$geo_long)
	{
	$query="INSERT INTO skola (nazev, mesto, geo_lat, geo_long) VALUES ('$nazev','$mesto','$geo_lat','$geo_long');";
	$this->db->query($query);
	}
}